<?php

$app['monolog.level'] = 'WARNING';