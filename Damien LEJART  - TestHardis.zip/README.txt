Installation:

- installer les vendors avec la commande: composer install
- le point d'entr� de l'application est le fichier "index.php" qui se trouve dans le dossier "web".
  il es  conseil de creer un h�te virtuel pointant sur ce dossier pour plus de praticit�
- L'application n�cessite le module appache "mod_rewrite" pour fonctionner


Utilisation:

- r�cup�ration des infos d'un adh�rent : /api/user/{id}
- r�cup�ration de la liste des adh�rents: /api/users

- Pour lancer les tests utiliser la command vendor/bin/phpunit tests